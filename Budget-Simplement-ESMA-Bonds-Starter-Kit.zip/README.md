# Budget simplement — ESMA bond catalogue starter kit

This bundle contains:
- `scripts/bonds_catalog.py`: downloads all parts of the latest complete `FULINS_D` ESMA publication, parses XML instrument records, filters CFI codes beginning with `D`, deduplicates ISINs, and writes a JSON catalogue only after a successful import.
- `.github/workflows/bonds-catalog.yml`: manual and weekly GitHub Actions workflow.
- `tests/`: a small XML fixture and parser test.

## Important limitations
- ESMA FIRDS is a reference database for instruments reported for trading/admission in the relevant EU regulatory scope; it is not a universal historical bond database.
- The initial workflow is deliberately separate from the live Netlify app. It does not deploy to Netlify or change production.
- The parser test uses a synthetic XML fixture. The real-world ESMA import still needs to be run in GitHub Actions and its output reviewed before using the catalogue in production.
- The initial output includes only fields found in the source. It does not invent missing coupons, maturities, issuer data, or market prices.

## Test locally
`python -m unittest discover -s tests -v`

## Run on GitHub
Upload the files while preserving the paths, commit them, then open Actions → Build ESMA bond catalogue → Run workflow.
